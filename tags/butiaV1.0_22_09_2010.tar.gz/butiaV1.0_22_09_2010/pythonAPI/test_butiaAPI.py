import butiaAPI
import time

#este modulo es para probar las funcionalidades de la api del butia "butiaAPI"

robot = butiaAPI()

cont = 0   
print "incio prueba" 

while True:  
	api.ping()
	time.sleep(10)
	cont = cont + 1
	print cont
    
print "adios"  
  
