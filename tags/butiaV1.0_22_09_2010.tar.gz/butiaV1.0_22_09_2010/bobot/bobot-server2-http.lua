module(..., package.seeall);

local devices=devices
local process = require("bobot-server2-process").process

local function load_template (filename)
	local served, err = io.open(filename, "r")
	if served then
		return served:read("*all")
	else
		print("Error opening template:", err)
	end
end
local index_template=load_template('indextemplate.txt')

local function parse_params(s)
	local params={}
	for k,v in string.gmatch(s, '([%w%%]+)=([%w%%]+)') do
		params[k]=v
	end
	return params
end


local page404="<html><head><title>404 Not Found</title></head><body><h3>404 Not Found!</h3><hr><small>bobot</small></body></html>"
local http404="HTTP/1.1 404 Not Found\r\nContent-Type:text/html\r\nContent-Length: "..#page404.."\r\n\r\n" .. page404
page404=nil
local function default_page()
	return http404
end

local get_page={}
setmetatable(get_page, {__index=function() return default_page end})
get_page["/index.htm"] = function (p)
	local params=parse_params(p)
	local rep = {
		['DATA1'] = params['campo'],
		['DATA2'] = tostring(params['unboton'])..', '..tostring(params['otroboton']),
	}
	local page=string.gsub(index_template, '<!%-%-(%w+)%-%->', rep)
	return "HTTP/1.1 200/OK\r\nContent-Type:text/html\r\nContent-Length: "..#page.."\r\n\r\n"..page
end
get_page["/"]=get_page["/index.htm"]
get_page["/dump.htm"] = function (p)
	local params=parse_params(p)
	local rep = {
		['LIST'] = process['LIST']
	}
	local page=string.gsub(dump_template, '<!%-%-(%w+)%-%->', rep)
	return "HTTP/1.1 200/OK\r\nContent-Type:text/html\r\nContent-Length: "..#page.."\r\n\r\n"..page
end
get_page["/favicon.ico"] = function ()
	local served, err = io.open('favicon.ico', "rb")
	if served ~= nil then
		local content = served:read("*all")
		return "HTTP/1.1 200/OK\r\nContent-Type:image/x-icon\r\nContent-Length: "
			..#content.."\r\n\r\n" .. content
	else
		print("Error opening favicon:", err)
		return default_page()
	end
end

function serve(skt)
	local line,err = skt:receive('*l') --read first line, must be GET or POST
	if err then return nil, err end

	local f,p=string.match(line, '^GET ([%/%.%d%w%-_]+)[%?]?(.-) HTTP/1.1$')
	if f then
		repeat
			--skip headers we don't care
			line,err=skt:receive()
		until line=='' or line==nil
		if err then return end
		local s=get_page[f](p)
		return(s..'\r\n')
	end

	local f,p=string.match(line, '^POST ([%/%.%d%w%-_]+) HTTP/1.1$')
	if f then
		local length
		repeat
			--skip headers we don't care
			line,err=skt:receive()
			length=length or string.match(line, '^Content%-Length%: (%d+)$')
		until line=='' or line==nil
		if err then return end
		local p=skt:receive(tonumber(length))
		local s=get_page[f](p)
		return(s..'\r\n')
	end
end

