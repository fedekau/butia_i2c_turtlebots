cd ../butiaXO/butia
./lua bobot-server.lua&
cd ../../pythonAPI
./waitforbobot.py
cd ../tortugarte/TurtleArtButia.activity94
./turtleart.py
kill `ps ax | grep bobot-server | grep -v grep | awk '{print $1}'`
