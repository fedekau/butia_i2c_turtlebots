#include <p18cxxx.h>
#include <xlcd.h>
#include <delays.h>

void DelayXLCD( void ){
Delay10KTCYx(10); //Delay of 5ms
return;
}


