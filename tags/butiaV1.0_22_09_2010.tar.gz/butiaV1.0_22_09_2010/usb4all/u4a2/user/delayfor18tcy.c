#include <p18cxxx.h>
#include <xlcd.h>

void DelayFor18TCY( void ){
Nop(); Nop(); Nop(); 
Nop(); Nop(); Nop(); 
Nop(); Nop(); Nop(); 
Nop(); Nop(); Nop();
Nop(); Nop(); Nop(); 
Nop(); Nop(); Nop();
}


