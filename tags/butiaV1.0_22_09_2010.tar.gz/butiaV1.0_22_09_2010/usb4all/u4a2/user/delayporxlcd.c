#include <p18cxxx.h>
#include "xlcd.h"
#include <delays.h>

void DelayPORXLCD( void ){
Delay10KTCYx(30); //Delay of 15ms
return;
}


